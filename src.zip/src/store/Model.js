export default class Model {
  getHash(){

  }
  getJSON(){
    
  }
}
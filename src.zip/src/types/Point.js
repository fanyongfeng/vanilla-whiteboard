export default class Point {
  
}
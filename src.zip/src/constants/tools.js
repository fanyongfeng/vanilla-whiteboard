/**
 * build-in tools
 */

 
const Tools = {

}


export default Tools;
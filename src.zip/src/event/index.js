import MouseEvent from './MouseEvent'

const emitMouseEvent = function(event){
  new MouseEvent()
}

function bindKeyboardEvent(event){
  //TODO:redo-undo, delete, move
}

export default {
  _registerMouseEvent(){},
  _registerKeyboardEvent(){},
  handleMouseMove(event){
    
  },

  handleMouseEvent(){

  }
}
/**
 * Mouse Event Class
 */
export default class MouseEvent {
  constructor(originEvent){
    this.originEvent = originEvent;
  }

}
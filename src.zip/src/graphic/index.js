import Arc from "./shape/Arc"

export default {
  Arc
}